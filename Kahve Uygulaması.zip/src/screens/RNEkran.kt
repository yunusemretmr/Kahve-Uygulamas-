package com.example.myapp
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.view.View
import com.bumptech.glide.Glide
class RNEkran : AppCompatActivity() {
	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_r_n_ekran)
		Glide.with(this).load("https://storage.googleapis.com/tagjs-prod.appspot.com/v1/QBMIP3muTg/oes1ptkv_expires_30_days.png").into(findViewById(R.id.r5isvdfr3hvv))
		Glide.with(this).load("https://storage.googleapis.com/tagjs-prod.appspot.com/v1/QBMIP3muTg/rvygp5l6_expires_30_days.png").into(findViewById(R.id.r1bzb6v86lll))
		Glide.with(this).load("https://storage.googleapis.com/tagjs-prod.appspot.com/v1/QBMIP3muTg/r2d43dss_expires_30_days.png").into(findViewById(R.id.riakvd5upjb7))
		Glide.with(this).load("https://storage.googleapis.com/tagjs-prod.appspot.com/v1/QBMIP3muTg/8prsflep_expires_30_days.png").into(findViewById(R.id.racsjc3pw4e7))
		Glide.with(this).load("https://storage.googleapis.com/tagjs-prod.appspot.com/v1/QBMIP3muTg/oro8qcmu_expires_30_days.png").into(findViewById(R.id.rz8be6vhz2jg))
		Glide.with(this).load("https://storage.googleapis.com/tagjs-prod.appspot.com/v1/QBMIP3muTg/4b5ipqh0_expires_30_days.png").into(findViewById(R.id.rtncn6yd1gq))
		Glide.with(this).load("https://storage.googleapis.com/tagjs-prod.appspot.com/v1/QBMIP3muTg/687vgfb1_expires_30_days.png").into(findViewById(R.id.rmnlb5yfp2kq))
		val button1: View = findViewById(R.id.rdlxyq83h4g4)
		button1.setOnClickListener {
			println("Pressed")
		}
		val button2: View = findViewById(R.id.rse40wy4svg)
		button2.setOnClickListener {
			println("Pressed")
		}
	}
}