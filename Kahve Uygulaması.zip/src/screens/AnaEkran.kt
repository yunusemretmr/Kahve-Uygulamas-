package com.example.myapp
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.view.View
import com.bumptech.glide.Glide
class AnaEkran : AppCompatActivity() {
	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_ana_ekran)
		Glide.with(this).load("https://storage.googleapis.com/tagjs-prod.appspot.com/v1/QBMIP3muTg/qobmwoy0_expires_30_days.png").into(findViewById(R.id.roiov0pwbatm))
		Glide.with(this).load("https://storage.googleapis.com/tagjs-prod.appspot.com/v1/QBMIP3muTg/km2yylmq_expires_30_days.png").into(findViewById(R.id.rl65sueu3gel))
		Glide.with(this).load("https://storage.googleapis.com/tagjs-prod.appspot.com/v1/QBMIP3muTg/0bqoodv2_expires_30_days.png").into(findViewById(R.id.rqsnyow9gdn))
		Glide.with(this).load("https://storage.googleapis.com/tagjs-prod.appspot.com/v1/QBMIP3muTg/xqaqmjgs_expires_30_days.png").into(findViewById(R.id.raeebfz4q8pu))
		Glide.with(this).load("https://storage.googleapis.com/tagjs-prod.appspot.com/v1/QBMIP3muTg/tfv8f9yd_expires_30_days.png").into(findViewById(R.id.rk4afq27c7vk))
		Glide.with(this).load("https://storage.googleapis.com/tagjs-prod.appspot.com/v1/QBMIP3muTg/1pw1ksyk_expires_30_days.png").into(findViewById(R.id.rmvpwect7w3))
		Glide.with(this).load("https://storage.googleapis.com/tagjs-prod.appspot.com/v1/QBMIP3muTg/xy2kuhb6_expires_30_days.png").into(findViewById(R.id.rnydeu7zozn))
		Glide.with(this).load("https://storage.googleapis.com/tagjs-prod.appspot.com/v1/QBMIP3muTg/94biswgs_expires_30_days.png").into(findViewById(R.id.rks7zvw0ub0f))
		Glide.with(this).load("https://storage.googleapis.com/tagjs-prod.appspot.com/v1/QBMIP3muTg/xrr1g9cy_expires_30_days.png").into(findViewById(R.id.rfn2l8fbmos5))
		Glide.with(this).load("https://storage.googleapis.com/tagjs-prod.appspot.com/v1/QBMIP3muTg/g6m5ygwc_expires_30_days.png").into(findViewById(R.id.r1ku4vr7qunx))
		Glide.with(this).load("https://storage.googleapis.com/tagjs-prod.appspot.com/v1/QBMIP3muTg/qd410acw_expires_30_days.png").into(findViewById(R.id.rhc9n4ub1wu5))
		Glide.with(this).load("https://storage.googleapis.com/tagjs-prod.appspot.com/v1/QBMIP3muTg/dfe6aumn_expires_30_days.png").into(findViewById(R.id.raiwg3h936em))
		Glide.with(this).load("https://storage.googleapis.com/tagjs-prod.appspot.com/v1/QBMIP3muTg/h8xhs54p_expires_30_days.png").into(findViewById(R.id.r0th4iy491uke))
		val button1: View = findViewById(R.id.rjcu52cc4zm)
		button1.setOnClickListener {
			println("Pressed")
		}
	}
}